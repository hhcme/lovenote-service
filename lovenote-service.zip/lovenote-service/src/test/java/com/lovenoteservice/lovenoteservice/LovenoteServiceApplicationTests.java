package com.lovenoteservice.lovenoteservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LovenoteServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
